# indexer.py
import json
from sentence_transformers import SentenceTransformer
import chromadb
import os

EMBED_MODEL = "all-MiniLM-L6-v2"
CHROMA_DIR = "./chroma_db"
BASE_FILE = "base.json"

def main():
    if not os.path.exists(BASE_FILE):
        print(f"File {BASE_FILE} tidak ditemukan.")
        return

    # Load JSON
    with open(BASE_FILE, "r", encoding="utf-8") as f:
        kb_list = json.load(f)

    docs = []
    ids = []
    metas = []

    for idx, item in enumerate(kb_list):
        # gabungkan semua value menjadi satu string untuk dokumen
        doc_text = " ".join([str(v) for v in item.values()])
        docs.append(doc_text)

        # ID unik (pakai id kalau ada, kalau tidak auto doc_n)
        if "id" in item:
            doc_id = item["id"]
        else:
            doc_id = f"doc_{idx}"
        ids.append(doc_id)

        # metadata: ubah semua value jadi string agar kompatibel
        meta = {k: str(v) for k, v in item.items()}
        metas.append(meta)

    print("Membuat embedding... (bisa memakan waktu beberapa detik)")
    embedder = SentenceTransformer(EMBED_MODEL)
    embeddings = embedder.encode(docs, convert_to_numpy=True, show_progress_bar=True)

    # ======== NEW Chroma Client API ========
    client = chromadb.PersistentClient(path=CHROMA_DIR)
    collection = client.get_or_create_collection(name="kb_collection")

    # pakai upsert biar update kalau id sama, bukan duplikat
    collection.upsert(
        ids=ids,
        documents=docs,
        metadatas=metas,
        embeddings=embeddings.tolist()
    )

    print("Indexing selesai. Total dokumen:", len(ids))

if __name__ == "__main__":
    main()
