# chatbot.py
import chromadb
import ollama
import random
from langdetect import detect
from datetime import datetime

# Untuk ekstrak teks dari file
from PyPDF2 import PdfReader
import docx
import openpyxl
from pptx import Presentation

CHROMA_DIR = "./chroma_db"
COLLECTION_NAME = "kb_collection"

# Inisialisasi ChromaDB offline
client = chromadb.PersistentClient(path=CHROMA_DIR)
collection = client.get_or_create_collection(name=COLLECTION_NAME)

# =========================
# Load system prompt dari file
# =========================
def load_system_prompt(filename, tone="formal, sopan, profesional"):
    try:
        with open(f"prompts/{filename}", "r", encoding="utf-8") as f:
            return f.read().format(tone=tone)
    except Exception as e:
        return f"[ERROR LOAD SYSTEM PROMPT: {str(e)}]"

# =========================
# Deteksi tone/gaya bahasa
# =========================
def detect_tone(query):
    informal_keywords = ["hai", "halo", "gimana", "bro", "sis", "oke", "gaul", "asik"]
    formal_keywords = ["tolong", "mohon", "jelaskan", "prosedur", "resmi", "sopan", "serius", "professional", "informasi", "detail", "spesifikasi"]
    query_lower = query.lower()
    if any(word in query_lower for word in formal_keywords):
        return random.choice(["formal, sopan, profesional", "sopan, jelas, informatif", "serius dan profesional"])
    elif any(word in query_lower for word in informal_keywords):
        return random.choice(["friendly, santai, hangat, ramah", "ceria, santai, hangat", "natural, akrab, ramah, sedikit gaul"])
    return random.choice(["friendly, sopan, hangat", "ramah, natural, menyenangkan", "santai, hangat, profesional tapi tidak kaku"])

# =========================
# Deteksi salam
# =========================
def detect_greeting(query):
    greetings = {
        "selamat pagi": "Selamat pagi",
        "selamat siang": "Selamat siang",
        "selamat sore": "Selamat sore",
        "selamat malam": "Selamat malam",
        "pagi": "Selamat pagi",
        "siang": "Selamat siang",
        "sore": "Selamat sore",
        "malam": "Selamat malam",
        "hai": "Hai",
        "halo": "Halo",
        "hi": "Hai",
        "hello": "Halo",
        "assalaamualaikum": "Waalaikumsalam",
        "assalamualaikum": "Waalaikumsalam",
        "waalaikumsalam": "Salam",
        "salam": "Salam",
        "permisi": "Iya",
        "misi": "Iya",
        "maaf mengganggu":"Iya",
        "misi kak, maaf mengganggu":"Iya",
    }
    query_lower = query.lower()
    for word, balasan in greetings.items():
        if word in query_lower:
            return balasan
    return None

# =========================
# Deteksi panggilan manusiawi
# =========================
def detect_addressing(query):
    return "kak"

# =========================
# Deteksi ucapan terima kasih
# =========================
def detect_thanks(query):
    thanks_keywords = ["terima kasih", "makasih", "thanks", "tq", "thank you", "thanks a lot", "makacih", "macih", "ty", "thank"]
    query_lower = query.lower()
    return any(word in query_lower for word in thanks_keywords)

# =========================
# Deteksi pertanyaan serius/profesional
# =========================
def detect_serious(query):
    serious_keywords = ["informasi", "detail", "spesifikasi", "cara", "prosedur", "resmi", "mohon", "tolong"]
    query_lower = query.lower()
    return any(word in query_lower for word in serious_keywords)

# =========================
# Deteksi bahasa
# =========================
def detect_language(query):
    try:
        lang = detect(query)
        return lang
    except:
        return 'id'

# =========================
# Cek jam operasional
# =========================
def cek_jam_operasional():
    sekarang = datetime.now()
    hari = sekarang.weekday()
    jam = sekarang.hour
    if hari < 6:  # Senin-Sabtu
        if 8 <= jam < 17:
            return "Saat ini masih jam kerja, Kak. Kami buka sampai pukul 17.00 WIB."
        elif jam < 8:
            return "Kantor belum buka, Kak. Kami mulai buka pukul 08.00 WIB."
        else:
            return "Kantor sudah tutup, Kak. Kami buka kembali besok pukul 08.00 WIB."
    else:
        return "Mohon maaf, Kak. Saat ini kantor sedang libur. Kami buka kembali pada hari Senin pukul 08.00 WIB."

# =========================
# Cek jam sekarang
# =========================
def cek_jam_sekarang():
    sekarang = datetime.now()
    return f"Sekarang pukul {sekarang.strftime('%H:%M')} WIB."

# =========================
# Fungsi ekstrak teks dari file
# =========================
def extract_text_from_file(file_storage):
    name = file_storage.filename.lower()
    text_content = ""
    try:
        if name.endswith(".pdf"):
            reader = PdfReader(file_storage)
            for page in reader.pages:
                text_content += page.extract_text() + "\n"
        elif name.endswith(".doc") or name.endswith(".docx"):
            doc = docx.Document(file_storage)
            for para in doc.paragraphs:
                text_content += para.text + "\n"
        elif name.endswith(".xls") or name.endswith(".xlsx"):
            wb = openpyxl.load_workbook(file_storage, data_only=True)
            for sheet in wb.worksheets:
                for row in sheet.iter_rows(values_only=True):
                    text_content += " ".join([str(cell) for cell in row if cell is not None]) + "\n"
        elif name.endswith(".ppt") or name.endswith(".pptx"):
            prs = Presentation(file_storage)
            for slide in prs.slides:
                for shape in slide.shapes:
                    if hasattr(shape, "text"):
                        text_content += shape.text + "\n"
        else:
            text_content += "[FORMAT FILE TIDAK DIDUKUNG]"
    except Exception as e:
        text_content += f"[ERROR MEMPROSES FILE: {str(e)}]"
    return text_content

# =========================
# Fungsi utama AI untuk query user
# =========================
def ai_answer(query, chat_count=0, k=5):
    addressing = detect_addressing(query)
    greeting_word = detect_greeting(query)
    query_lower = query.lower()
    
    if chat_count == 0:
        return f"Halo {addressing}, selamat datang di layanan pelanggan kami! Ada yang bisa saya bantu?"
    if greeting_word:
        return f"{greeting_word} {addressing}! Ada yang bisa saya bantu?"
    if detect_thanks(query):
        thanks_variations = [
            f"Sama-sama {addressing}! Senang bisa membantu 😄",
            f"Tentu {addressing}, sama-sama! 😊",
            f"Senang bisa membantu, {addressing}!"
        ]
        return random.choice(thanks_variations)
    if any(word in query_lower for word in ["buka", "tutup", "jam kerja", "operasional", "open", "close"]):
        return cek_jam_operasional()
    if any(word in query_lower for word in ["jam berapa", "pukul berapa", "waktu sekarang"]):
        return cek_jam_sekarang()

    # Ambil konteks dari vector DB
    try:
        results = collection.query(query_texts=[query], n_results=k)
        docs = results.get('documents', [[]])[0] if results else []
        context = "\n".join(docs) if docs else ""
    except:
        context = ""

    tone = "formal, sopan, profesional" if detect_serious(query) else detect_tone(query)
    offer_product = chat_count >= 15
    product_text = "\nBerikut beberapa produk yang bisa kami tawarkan:" if offer_product else ""
    system_prompt = load_system_prompt("default.txt", tone=tone)

    prompt = f"""{system_prompt}

{product_text}

Konteks pertanyaan sebelumnya:
{context}

Pertanyaan pelanggan:
{query}

Jawaban:
"""
    try:
        response = ollama.chat(
            model="mistral",
            messages=[{"role": "user", "content": prompt}],
            stream=False
        )
        if hasattr(response, "message") and hasattr(response.message, "content"):
            return response.message.content.strip()
        elif isinstance(response, list) and len(response) > 0:
            for item in response:
                if hasattr(item, "message") and hasattr(item.message, "content"):
                    return item.message.content.strip()
        return "Maaf, saya belum bisa menjawab pertanyaan itu 😅"
    except:
        return "Maaf, terjadi masalah saat memproses jawaban 😅"

# =========================
# Fungsi AI untuk query + file + RAG
# =========================
def ai_answer_files(file_storages, user_query="", chat_count=0, k=5):
    addressing = detect_addressing(user_query)
    query_lower = user_query.lower()
    
    # Salam/ucapan terima kasih
    greeting_word = detect_greeting(user_query)
    if chat_count == 0:
        return f"Halo {addressing}, selamat datang di layanan pelanggan kami! Ada yang bisa saya bantu?"
    if greeting_word:
        return f"{greeting_word} {addressing}! Ada yang bisa saya bantu?"
    if detect_thanks(user_query):
        thanks_variations = [
            f"Sama-sama {addressing}! Senang bisa membantu 😄",
            f"Tentu {addressing}, sama-sama! 😊",
            f"Senang bisa membantu, {addressing}!"
        ]
        return random.choice(thanks_variations)
    if any(word in query_lower for word in ["buka", "tutup", "jam kerja", "operasional", "open", "close"]):
        return cek_jam_operasional()
    if any(word in query_lower for word in ["jam berapa", "pukul berapa", "waktu sekarang"]):
        return cek_jam_sekarang()
    
    # Ekstrak teks dari file
    file_texts = [extract_text_from_file(f) for f in file_storages]
    combined_file_text = "\n".join(file_texts) if file_texts else ""

    # Ambil konteks dari vector DB (RAG)
    try:
        results = collection.query(query_texts=[user_query], n_results=k)
        docs = results.get('documents', [[]])[0] if results else []
        context_from_db = "\n".join(docs) if docs else ""
    except:
        context_from_db = ""

    tone = "formal, sopan, profesional" if detect_serious(user_query) else detect_tone(user_query)
    system_prompt = load_system_prompt("with_file.txt", tone=tone)

    # Prioritas konteks
    if combined_file_text.strip():
        prompt_context = f"Konteks file:\n{combined_file_text}"
        if len(combined_file_text) < 50 and context_from_db.strip():
            prompt_context += f"\nKonteks tambahan dari database:\n{context_from_db}"
    else:
        prompt_context = f"Konteks dari database:\n{context_from_db}"

    prompt = f"""{system_prompt}

{prompt_context}

Pertanyaan pelanggan:
{user_query}

Jawaban:
"""
    try:
        response = ollama.chat(
            model="mistral",
            messages=[{"role": "user", "content": prompt}],
            stream=False
        )
        if hasattr(response, "message") and hasattr(response.message, "content"):
            return response.message.content.strip()
        elif isinstance(response, list) and len(response) > 0:
            for item in response:
                if hasattr(item, "message") and hasattr(item.message, "content"):
                    return item.message.content.strip()
        return "Maaf, saya belum bisa menjawab pertanyaan itu 😅"
    except:
        return "Maaf, terjadi masalah saat memproses jawaban 😅"
