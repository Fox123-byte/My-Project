from flask import Flask, request, jsonify, render_template, session
import os
import chatbot
from flask_session import Session
from functools import wraps
import threading

app = Flask(__name__, template_folder=os.path.dirname(os.path.abspath(__file__)))
app.secret_key = "super-secret-key-123"
app.config["SESSION_TYPE"] = "filesystem"
app.config["MAX_CONTENT_LENGTH"] = 30 * 1024 * 1024  # Maks 30MB per file
Session(app)

SUPPORTED_EXTENSIONS = (".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx")

# 🔹 Mapping API Key ke client
API_KEYS = {
    "1C?T8o+}IO3mus&j.qqia.CgJ": {"client_id": "user1", "active": True},
    "6g9a)k!.ng!beQ6]@O}yxf%7k": {"client_id": "user2", "active": True},
    "12345678": {"client_id": "user3", "active": True},
}

# 🔹 Lock per API Key supaya tidak bisa dipakai bersamaan
API_KEY_LOCKS = {key: threading.Lock() for key in API_KEYS}


# 🔹 Dekorator untuk cek API Key + Lock
def require_api_key(func):
    @wraps(func)
    def decorated_function(*args, **kwargs):
        api_key = request.headers.get("x-api-key") or request.args.get("api_key")
        if not api_key or api_key not in API_KEYS:
            return jsonify({"error": "❌ API Key tidak valid"}), 401

        client_info = API_KEYS[api_key]
        if not client_info["active"]:
            return jsonify({"error": "❌ API Key ini sudah dinonaktifkan"}), 403

        lock = API_KEY_LOCKS[api_key]
        if not lock.acquire(blocking=False):  # API Key sedang dipakai
            return jsonify({"error": "❌ API Key sedang digunakan oleh client lain."}), 429

        try:
            request.client_id = client_info["client_id"]
            return func(*args, **kwargs)
        finally:
            lock.release()  # Lepaskan lock setelah request selesai
    return decorated_function


@app.route("/")
def index():
    return render_template("ui.html")


@app.route("/ask", methods=["POST"])
def ask():
    data = request.get_json(silent=True)
    text_query = data.get("message", "").strip() if data else ""
    if not text_query:
        text_query = request.form.get("message", "").strip()

    files = request.files.getlist("files")
    valid_files, invalid_files = [], []
    if files:
        for f in files:
            filename = f.filename
            if filename and filename.lower().endswith(SUPPORTED_EXTENSIONS):
                valid_files.append(f)
            else:
                invalid_files.append(filename)

    if not text_query and not valid_files:
        return jsonify({"answer": "⚠️ Pertanyaan atau file harus diisi."})

    chat_count = session.get("chat_count", 0) + 1
    session["chat_count"] = chat_count

    try:
        if valid_files:
            answer = chatbot.ai_answer_files(valid_files, user_query=text_query, chat_count=chat_count)
            if invalid_files:
                answer += f"\n⚠️ Beberapa file tidak didukung: {', '.join(invalid_files)}"
        else:
            answer = chatbot.ai_answer(text_query, chat_count=chat_count)
    except Exception as e:
        answer = f"Maaf, terjadi error saat memproses input. ({str(e)})"

    return jsonify({"answer": answer})


# 🔹 Endpoint API: hanya menerima teks
@app.route("/api/ask", methods=["POST"])
@require_api_key
def api_ask():
    data = request.get_json(silent=True)
    if not data or "message" not in data:
        return jsonify({"error": "⚠️ Parameter 'message' wajib diisi."}), 400

    text_query = data["message"].strip()
    if not text_query:
        return jsonify({"error": "⚠️ Pesan tidak boleh kosong."}), 400

    chat_count = session.get("chat_count", 0) + 1
    session["chat_count"] = chat_count

    try:
        answer = chatbot.ai_answer(text_query, chat_count=chat_count)
    except Exception as e:
        return jsonify({"error": f"Terjadi error: {str(e)}"}), 500

    return jsonify({
        "answer": answer,
        "client_id": request.client_id
    })


# 🔹 Endpoint API: menerima teks + file
@app.route("/api/ask_with_files", methods=["POST"])
@require_api_key
def api_ask_with_files():
    text_query = request.form.get("message", "").strip()
    files = request.files.getlist("files")
    valid_files, invalid_files = [], []

    if files:
        for f in files:
            filename = f.filename
            if filename and filename.lower().endswith(SUPPORTED_EXTENSIONS):
                valid_files.append(f)
            else:
                invalid_files.append(filename)

    if not text_query and not valid_files:
        return jsonify({"error": "⚠️ Pesan atau file harus diisi."}), 400

    chat_count = session.get("chat_count", 0) + 1
    session["chat_count"] = chat_count

    try:
        if valid_files:
            answer = chatbot.ai_answer_files(valid_files, user_query=text_query, chat_count=chat_count)
            if invalid_files:
                answer += f"\n⚠️ Beberapa file tidak didukung: {', '.join(invalid_files)}"
        else:
            answer = chatbot.ai_answer(text_query, chat_count=chat_count)
    except Exception as e:
        return jsonify({"error": f"Terjadi error: {str(e)}"}), 500

    return jsonify({
        "answer": answer,
        "client_id": request.client_id
    })


# 🔹 Endpoint untuk reset chat_count
@app.route("/reset_chat", methods=["POST"])
def reset_chat():
    session["chat_count"] = 0
    return jsonify({"answer": "✅ Sesi chat berhasil direset. Chat count kembali ke 0."})


if __name__ == "__main__":
    print("==== SERVER STARTED ====")
    app.run(debug=True, port=5000)
