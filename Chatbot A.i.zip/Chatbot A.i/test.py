# =========================
# Fungsi ekstrak teks dari file
# =========================
def extract_text_from_file(file_storage):
    name = file_storage.filename.lower()
    text_content = ""
    try:
        if name.endswith(".pdf"):
            reader = PdfReader(file_storage)
            for page in reader.pages:
                text_content += page.extract_text() + "\n"
        elif name.endswith(".doc") or name.endswith(".docx"):
            doc = docx.Document(file_storage)
            for para in doc.paragraphs:
                text_content += para.text + "\n"
        elif name.endswith(".xls") or name.endswith(".xlsx"):
            wb = openpyxl.load_workbook(file_storage, data_only=True)
            for sheet in wb.worksheets:
                for row in sheet.iter_rows(values_only=True):
                    text_content += " ".join([str(cell) for cell in row if cell is not None]) + "\n"
        elif name.endswith(".ppt") or name.endswith(".pptx"):
            prs = Presentation(file_storage)
            for slide in prs.slides:
                for shape in slide.shapes:
                    if hasattr(shape, "text"):
                        text_content += shape.text + "\n"
        else:
            text_content += "[FORMAT FILE TIDAK DIDUKUNG]"
    except Exception as e:
        text_content += f"[ERROR MEMPROSES FILE: {str(e)}]"
    
    print(f"==== EKSTRAKSI FILE: {file_storage.filename} ====")
    print(text_content[:500])
    return text_content.strip()

# =========================
# Fungsi AI dengan file
# =========================
def ai_answer_files(file_storages, user_query="", chat_count=0, k=5):
    addressing = "kak"
    if chat_count == 0:
        return f"Halo {addressing}, selamat datang di layanan pelanggan kami! Ada yang bisa saya bantu?"

    # Ekstrak teks dari semua file
    file_texts = [extract_text_from_file(f) for f in file_storages]
    combined_file_text = "\n".join(file_texts).strip() if file_texts else ""

    # =================================
    # 1️⃣ Prioritas: tampilkan isi file kalau diminta
    # =================================
    show_file_keywords = ["tuliskan isi file", "tampilkan isi file", "apa isi file"]
    if any(word in user_query.lower() for word in show_file_keywords):
        return combined_file_text if combined_file_text else "File kosong atau tidak bisa dibaca"

    # =================================
    # 2️⃣ Cek relevansi file untuk menjawab pertanyaan
    # =================================
    def is_file_relevant(file_text, query):
        # sangat sederhana: cek ada kata kunci yang sama
        query_words = set(query.lower().split())
        file_words = set(file_text.lower().split())
        return len(query_words & file_words) > 0

    file_relevant = any(is_file_relevant(text, user_query) for text in file_texts)

    tone = detect_tone(user_query)

    # ==== Jawab dari file jika relevan ====
    if combined_file_text and file_relevant:
        prompt_file = f"""
Kamu adalah customer service AI profesional untuk aplikasi belanja online.
- Gunakan gaya bahasa: {tone}
- Jika informasi di file cukup, jawab dari file
- Jika tidak cukup, jawab persis: "TIDAK CUKUP, LANJUTKAN DB"

Konteks file:
{combined_file_text}

Pertanyaan pelanggan:
{user_query}

Jawaban:
"""
        print("==== PROMPT FILE ====")
        print(prompt_file[:1000])

        try:
            response_file = ollama.chat(
                model="mistral",
                messages=[{"role": "user", "content": prompt_file}],
                stream=False
            )
            if hasattr(response_file, "message") and hasattr(response_file.message, "content"):
                file_answer = response_file.message.content.strip()
            elif isinstance(response_file, list) and len(response_file) > 0:
                file_answer = response_file[0].message.content.strip()
            else:
                file_answer = ""
            
            if "TIDAK CUKUP" not in file_answer.upper():
                return file_answer
        except Exception as e:
            print(f"==== ERROR FILE ANSWER ====")
            print(e)

    # =================================
    # 3️⃣ Fallback ke database
    # =================================
    try:
        results = collection.query(query_texts=[user_query], n_results=k)
        docs = results.get('documents', [[]])[0] if results else []
        context_from_db = "\n".join(docs) if docs else ""
    except Exception as e:
        context_from_db = ""
        print(f"==== ERROR RAG DB: {e} ====")

    prompt_db = f"""
Kamu adalah customer service AI profesional untuk aplikasi belanja online.
- Gunakan gaya bahasa: {tone}
- Jawaban minimal 1 kalimat, maksimal 2 kalimat
- Gunakan konteks dari database berikut

Konteks database:
{context_from_db}

Pertanyaan pelanggan:
{user_query}

Jawaban:
"""
    print("==== PROMPT DB (FALLBACK) ====")
    print(prompt_db[:1000])

    try:
        response_db = ollama.chat(
            model="mistral",
            messages=[{"role": "user", "content": prompt_db}],
            stream=False
        )
        if hasattr(response_db, "message") and hasattr(response_db.message, "content"):
            return response_db.message.content.strip()
        elif isinstance(response_db, list) and len(response_db) > 0:
            return response_db[0].message.content.strip()
        return "Maaf, saya belum bisa menjawab pertanyaan itu 😅"
    except Exception as e:
        print(f"==== ERROR DB ANSWER ====")
        print(e)
        return "Maaf, terjadi masalah saat memproses jawaban 😅"