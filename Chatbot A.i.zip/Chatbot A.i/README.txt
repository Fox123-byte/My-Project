Langkah-Langkah menggunakan model A.I mistral Ollama

1. Install ollama 
2. Install model mistral (7B atau parameter yang lebih tinggi jika spesifikasi perangkat mendukung)
3. Running code python file "app.py"

4. Jika ingin menggunakan API, gunakan API key yang sudah disediakaan di codingan app.py