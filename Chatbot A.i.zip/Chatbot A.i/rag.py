# rag.py
import chromadb

CHROMA_DIR = "./chroma_db"
COLLECTION_NAME = "kb_collection"

# Inisialisasi ChromaDB versi baru
client = chromadb.PersistentClient(path=CHROMA_DIR)
collection = client.get_or_create_collection(name=COLLECTION_NAME)

def get_docs(query, k=5):
    """
    Mengambil dokumen terdekat dari ChromaDB
    """
    results = collection.query(query_texts=[query], n_results=k)
    docs = results['documents'][0] if 'documents' in results else []
    return docs
